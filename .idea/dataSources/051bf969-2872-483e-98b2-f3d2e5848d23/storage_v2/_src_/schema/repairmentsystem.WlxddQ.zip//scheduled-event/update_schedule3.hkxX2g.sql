create definer = root@`%` event update_schedule3 on schedule
  every '1' DAY
    starts '2019-03-15 10:10:00'
  on completion preserve
  enable
  do
  begin
call  update_schedule_status3();
end;

