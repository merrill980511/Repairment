create definer = root@`%` event update_schedule1 on schedule
  every '1' DAY
    starts '2019-03-15 08:00:00'
  on completion preserve
  enable
  do
  begin
call  update_schedule_status1();
end;

