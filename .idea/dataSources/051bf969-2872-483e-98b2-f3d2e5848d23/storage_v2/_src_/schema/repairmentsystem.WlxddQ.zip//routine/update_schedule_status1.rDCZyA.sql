create procedure update_schedule_status1()
BEGIN
    IF exists (select id from `schedule` where SYSDATE()=`date` and number = 1 and `status` in (0, 8, 10)) THEN
            update `schedule` set `status`= 4
            where id in  (select id from (select id from `schedule` where SYSDATE()=`date` and number = 1 and `status` in (0, 8, 10)) as tmp1);
    END IF;
END;

