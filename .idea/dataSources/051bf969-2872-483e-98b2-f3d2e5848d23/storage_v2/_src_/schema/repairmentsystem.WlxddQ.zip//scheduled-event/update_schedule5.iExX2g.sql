create definer = root@`%` event update_schedule5 on schedule
  every '1' DAY
    starts '2019-03-15 13:30:00'
  on completion preserve
  enable
  do
  begin
call  update_schedule_status5();
end;

