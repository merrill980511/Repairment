create procedure update_schedule_status4()
BEGIN
    IF exists (select id from `schedule` where SYSDATE()=`date` and number = 2 and `status` in (0, 8, 10)) THEN
            update `schedule` set `status`= 3
            where id in  (select id from (select id from `schedule` where SYSDATE()=`date` and number = 2 and `status`=0) as tmp1);
    END IF;
END;

