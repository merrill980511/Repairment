create definer = root@`%` event update_schedule6 on schedule
  every '1' DAY
    starts '2019-03-15 15:20:00'
  on completion preserve
  enable
  do
  begin
call  update_schedule_status6();
end;

