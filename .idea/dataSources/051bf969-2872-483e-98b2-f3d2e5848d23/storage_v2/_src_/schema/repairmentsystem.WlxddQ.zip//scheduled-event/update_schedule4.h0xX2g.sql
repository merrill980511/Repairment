create definer = root@`%` event update_schedule4 on schedule
  every '1' DAY
    starts '2019-03-15 11:50:00'
  on completion preserve
  enable
  do
  begin
call  update_schedule_status4();
end;

