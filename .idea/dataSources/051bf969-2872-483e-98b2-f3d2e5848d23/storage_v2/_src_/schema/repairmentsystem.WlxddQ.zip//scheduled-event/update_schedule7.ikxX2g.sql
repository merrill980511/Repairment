create definer = root@`%` event update_schedule7 on schedule
  every '1' DAY
    starts '2019-03-15 15:40:00'
  on completion preserve
  enable
  do
  begin
call  update_schedule_status7();
end;

